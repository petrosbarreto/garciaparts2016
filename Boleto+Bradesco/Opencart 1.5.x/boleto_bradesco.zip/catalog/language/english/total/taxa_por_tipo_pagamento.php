<?php
$_['text_taxa_por_tipo_pagamento'] = 'Payment Method Fee';
?>