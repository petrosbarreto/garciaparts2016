<?php
// Text
$_['text_title'] = 'Mercadopago';
$_['currency_no_support'] = 'Currency not suported in Mercadopago';