<?php
// Text
$_['text_title'] = '<img src="image/mp.png" alt="Mercado pago" title="Mercado Pago"  />';
$_['currency_no_support'] = 'La moneda seleccionada no es aceptada por MercadoPago';